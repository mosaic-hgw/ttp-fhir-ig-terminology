# Implementation Guide Terminology - v2025.2.0

